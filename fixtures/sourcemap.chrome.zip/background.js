export function billingSecret(){return"this-is-the-plot-twist"}
//# sourceMappingURL=background.js.map
